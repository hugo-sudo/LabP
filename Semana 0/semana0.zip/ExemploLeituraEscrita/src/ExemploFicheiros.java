import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.stream.IntStream;

public class ExemploFicheiros {
	
	public static void copiaTexto (String fileIn, String fileOut) throws FileNotFoundException {
		Scanner leitor = new Scanner (new File (fileIn));
		PrintWriter escritor = new PrintWriter (new File (fileOut));
		while (leitor.hasNextLine()) {
			String linha = leitor.nextLine();
			escritor.println (linha);
		}
		leitor.close();
		escritor.close();
	}
	
	public static void escreveQuadrados (String fileIn, String fileOut) throws FileNotFoundException {
		Scanner leitor = new Scanner (new File (fileIn));
		PrintWriter escritor = new PrintWriter (new File (fileOut));
		while (leitor.hasNextInt()) {
			int valor = leitor.nextInt();
			escritor.println(valor * valor);
		}
		leitor.close();
		escritor.close();
	}
	
	public static void guardaMultiplos (String fileIn, String fileOut, int n) throws FileNotFoundException {
		Scanner leitor = new Scanner (new File (fileIn));
		PrintWriter escritor = new PrintWriter (new File (fileOut));
		while (leitor.hasNextInt()) {
			int valor = leitor.nextInt();
			if (valor % n == 0) {
				escritor.println(valor);
			}
		}
		escritor.close();
		leitor.close();
	}
	
	public static void minusculasMaiusculas (String fileIn, String fileOut) throws FileNotFoundException {
		Scanner leitor = new Scanner (new File (fileIn));
		PrintWriter escritor = new PrintWriter (new File (fileOut));
		int n = 0;
		while (leitor.hasNextLine()) {
			String linha = leitor.nextLine();
			if (n % 2 == 0) {
				escritor.println(linha.toLowerCase());
				n+=1;
			}
			else {
				escritor.println(linha.toUpperCase());
				n += 1;
			}
		}
		leitor.close();
		escritor.close();
	}
	
	public static void elementosEmComum (String fileIn, String fileOut, int[] vals) throws FileNotFoundException {
		Scanner leitor = new Scanner (new File (fileIn));
		PrintWriter escritor = new PrintWriter (new File (fileOut));
		while (leitor.hasNextInt()){
			int valor = leitor.nextInt();
			boolean result = IntStream.of(vals).anyMatch(x -> x == valor);
			if (result) {
				escritor.println (valor);
			}
		}
		leitor.close();
		escritor.close();
	}
}
