import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.Test;

public class ExemploTestTest {



	@Test
	public void testCopiaTexto () throws IOException {

		String esperado = "abcdefghijklmnopqrstuvwxyz" + "\n";

		String texto = "abcdefghijklmnopqrstuvwxyz";

		PrintWriter in = new PrintWriter("input.txt");
		in.write(texto);
		in.close();

		ExemploFicheiros.copiaTexto("input.txt", "output.txt");
		String obtida = new String(Files.readAllBytes(Paths.get("output.txt")), StandardCharsets.UTF_8);

		assertEquals(esperado, obtida);
	}

	@Test
	public void testMinusculasMaiusculas () throws IOException {
		String esperado = "abcdefghi" + "\n" + "JKLMNOPQRSTUVWXYZ" + "\n";

		String texto = "ABcdefghi" + "\n" + "jklmnopqrstuvWXYZ";

		PrintWriter in = new PrintWriter("input.txt");
		in.write(texto);
		in.close();

		ExemploFicheiros.minusculasMaiusculas("input.txt", "output.txt");
		String obtida = new String(Files.readAllBytes(Paths.get("output.txt")), StandardCharsets.UTF_8);

		assertEquals(esperado, obtida);
	}

	@Test
	public void testGuardaMultiplos () throws IOException {
		String esperado = 	"12" + "\n" + "30" + "\n" + "15" + "\n";

		String texto = "12" + "\n" + "11" + "\n" + "30" + "\n" + "15" + "\n" + "32";

		PrintWriter in = new PrintWriter("input.txt");
		in.write(texto);
		in.close();

		ExemploFicheiros.guardaMultiplos("input.txt", "output.txt",3);
		String obtida = new String(Files.readAllBytes(Paths.get("output.txt")), StandardCharsets.UTF_8);

		assertEquals(esperado, obtida);
	}

	@Test
	public void testEscreveQuadrados () throws IOException {
		String esperado = 	"25" + "\n" + "4" + "\n" + "36" + "\n" + "16" + "\n";

		String texto = "5" + "\n" + "2" + "\n" + "6" + "\n" + "4" + "\n";
		PrintWriter in = new PrintWriter("input.txt");
		in.write(texto);
		in.close();

		ExemploFicheiros.escreveQuadrados("input.txt", "output.txt");
		String obtida = new String(Files.readAllBytes(Paths.get("output.txt")), StandardCharsets.UTF_8);

		assertEquals(esperado, obtida);	
	}

	@Test
	public void testElementosEmComum () throws IOException {

		String esperado = 	"1" + "\n" + "5" + "\n" + "11" + "\n" + "21" + "\n" +
				            "15" + "\n" + "1" + "\n";

	    int[] vals = {1, 5, 11, 15, 21, 25};

		String texto = "1"+ "\n" + "4" + "\n" + "5" + "\n" + "2" + "4"+ "\n" + 
		               "11"+ "\n" + "33" + "\n" + "21" + "\n" + "123" + "\n"+ 
				       "15" + "\n" + "10" + "\n" + "1";
		PrintWriter in = new PrintWriter("input.txt");
		in.write(texto);
		in.close();
		
		ExemploFicheiros.elementosEmComum("input.txt", "output.txt",vals);
		String obtida = new String(Files.readAllBytes(Paths.get("output.txt")), StandardCharsets.UTF_8);
		assertEquals(esperado, obtida);	
	}
}
