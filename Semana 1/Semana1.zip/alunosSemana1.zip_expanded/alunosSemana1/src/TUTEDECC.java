import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class TUTEDECC {
	public static void inverteLinhas (String fileIn, String fileOut) throws FileNotFoundException {
		Scanner inicial = new Scanner(new File(fileIn));
		PrintWriter escritor = new PrintWriter (fileOut);
		
		while (inicial.hasNextLine()) {
			StringBuilder input = new StringBuilder();
			String linha = inicial.nextLine();
			input.append (linha);
			input = input.reverse();
			escritor.println(input.toString());
		}
		inicial.close();
		escritor.close();
	}
	public static void trocaLinhas (String fileIn, String fileOut) throws FileNotFoundException {
		Scanner inicial = new Scanner(new File(fileIn));
		PrintWriter escritor = new PrintWriter (fileOut);
		String lines = "";
		while (inicial.hasNextLine()) {
			String linha = inicial.nextLine();
			lines = lines + linha + "\n";
			String [] individual = lines.split("\n");
			if (individual.length % 2 == 0) {
				escritor.println (individual[individual.length - 1]);
				escritor.println (individual[individual.length - 2]);
			}
		}
		inicial.close();
		escritor.close();
	}
	public static void duplicaCarateres (String fileIn, String fileLetras, String fileOut) throws FileNotFoundException {
		Scanner inicial = new Scanner(new File(fileIn));
		Scanner duplicar = new Scanner(new File(fileLetras));
		PrintWriter escritor = new PrintWriter (fileOut);
		String duplicado = duplicar.next();
		System.out.println(duplicado);
		String letras = "";
		for (int i = 0; i < duplicado.length(); i ++) {
			letras += duplicado.charAt(i) + "-";
		}
		String [] letrasIndividual = letras.split("-");
		while (inicial.hasNextLine()) {
			StringBuilder fraseFinal = new StringBuilder("");
			String frase = inicial.nextLine();
			String [] palavrasIniciais = frase.split(" ");
			for (String b : palavrasIniciais) {
				StringBuilder palavraFinal = new StringBuilder (b);
				for (String a : letrasIndividual) {
					if (b.indexOf(a) >= 0) {
						palavraFinal.insert(b.indexOf(a)+1, a);
					}
				}
				fraseFinal.append(palavraFinal);
				fraseFinal.append(" ");
			}
			fraseFinal.deleteCharAt(fraseFinal.length() - 1);
			escritor.print(fraseFinal.toString() + "\n");
			System.out.println(fraseFinal);
		}
		inicial.close();
		duplicar.close();
		escritor.close();
	}
	public static void cifraCeaser (String fileIn, String fileOut) throws FileNotFoundException {
		Scanner inicial = new Scanner(new File(fileIn));
		PrintWriter escritor = new PrintWriter (fileOut);
		int cifrado;
		int pInicial;
		int valor = 1;
		
		while (inicial.hasNextLine()) {
			String line = inicial.nextLine();
			String [] words = line.split(" ");
			StringBuilder palavraFinal = new StringBuilder ("");
			for (String b : words) {
				for (int i = 0; i < b.length(); i ++) {
					char c = b.charAt(i);
					pInicial = c;
					cifrado = c + valor;
					palavraFinal.append((char) cifrado);
				}
				palavraFinal.append(" ");
			}
			valor += 1;
			palavraFinal.delete(palavraFinal.length()-1, palavraFinal.length());
			escritor.print(palavraFinal.toString());
			escritor.print("\n");
		}
		inicial.close();
		escritor.close();
	}
	public static void linhasMesmoComprimento (String fileIn, int n, String fileOut) throws FileNotFoundException {
		Scanner inicial = new Scanner(new File(fileIn));
		PrintWriter escritor = new PrintWriter (fileOut);
		
		while (inicial.hasNextLine()) {
			String line = inicial.nextLine();
			
		}
	}
}
