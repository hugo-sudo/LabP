import java.io.FileNotFoundException;

public class RunSudoku {

	public static void main(String[] args) throws FileNotFoundException {
		Sudoku.verificaQuadrado ("/Users/hugo/eclipse-workspace/Sudoku/Testes/exemplo1.txt");

	}

}
