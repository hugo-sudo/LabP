import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Sudoku {
	public static String verificaQuadrado(String fileIn) throws FileNotFoundException {
		
		Scanner leitor = new Scanner (new File (fileIn));
		int contador = 0;
		String [][] todasLinhas = new String[9][9];
		String [][] todasColunas = new String[9][9];
		String [][] quadrados = new String [3][9];
		
		while (leitor.hasNextLine()) {
			String line = leitor.nextLine();
			String [] numeros = line.split(" ");
			todasLinhas [contador] = numeros;
			for (int i = 0; i < numeros.length; i ++) {
				for (int j = i + 1; j < numeros.length; j ++) {
					if (numeros[i].equals(numeros[j])) {
						leitor.close();
						System.out.println("O puzzle seguinte está errado: " + "\n" + sudokuPuzzle(fileIn));
						return "O puzzle seguinte está errado: " + "\n" + sudokuPuzzle(fileIn);
					}
				}
			}
		}
		int count = 0;
		int countCycle = 0;
		for (String [] a : todasLinhas) {
			for (int i = 0; i < a.length; i = i +3) {
				quadrados [count][i] = a[i];
				quadrados [count][i + 1] = a[i + 1];
				quadrados [count][i + 2] = a[i + 2];
				count += 1;
			}
			count = 0;
			countCycle += 1;
			if (countCycle % 3 == 0) {
				for (String [] b : quadrados) {
					for (int i = 0; i < b.length; i ++) {
						System.out.println(b[i]);
						for (int j = i + 1; j < b.length; j ++) {
							if (b[i].equals(b[j])) {
								leitor.close();
								System.out.println("O puzzle seguinte está errado: " + "\n" + sudokuPuzzle(fileIn));
								return "O puzzle seguinte está errado: " + "\n" + sudokuPuzzle(fileIn);
							}
						}
					}
				}
				quadrados = new String [3][9];
			}
		}
		for (int i = 0; i < todasLinhas[0].length; i++) {
            for (int j = 0; j < todasLinhas.length; j++) {
            	todasColunas [j][i] = todasLinhas [j][i];
            }
		}
		for (int i = 0; i < todasColunas.length; i ++) {
			for (int j = i + 1; j < todasColunas.length; j ++) {
				if (todasColunas[i].equals(todasColunas[j])) {
					leitor.close();
					System.out.println("O puzzle seguinte está errado: " + "\n" + sudokuPuzzle(fileIn));
					return "O puzzle seguinte está errado: " + "\n" + sudokuPuzzle(fileIn);
				}
			}
		}
		leitor.close();
		System.out.println("O jogo respeita as regras do Sudoku");
		return "O jogo respeita as regras do Sudoku";
	}
	public static String sudokuPuzzle (String fileIn) throws FileNotFoundException {
		
		Scanner leitor = new Scanner (new File (fileIn));
		
		StringBuilder puzzle = new StringBuilder ("+-----+-----+-----+" + "\n");
		
		int contador = 0;
		
		while (leitor.hasNextLine()) {
			String line = leitor.nextLine();
			String [] numeros = line.split(" ");
			puzzle.append("|");
			for (int i = 0; i < numeros.length; i = i + 3) {
				puzzle.append(numeros[i] + " " + numeros[i + 1] + " " + numeros[i + 2] + "|");
			}
			contador += 1;
			puzzle.append("\n");
			if (contador % 3 == 0) {
				puzzle.append("+-----+-----+-----+" + "\n");
			}
		}
		leitor.close();
		return (puzzle.toString());
		
	}
}
