public class Calculadora {
  //o valor do numero Pi
    private static final  double PI = 3.14; 
    private int numeroDeCalculos = 0;
    private static final int MULTIPLIER = 10;

    public boolean ehMultiplo (int valor, int n) {
        this.numeroDeCalculos++;
        return(valor % n == 0);
    }

    //vou precisar de mudar o PI?
    public void setPi(int quantasCasas) {
        // por fazer
    }

    public double numeroPi() {
        return PI;
    }

    public int numeroCalculos() {
        return numeroDeCalculos;
    }

    public static void ehPotenciaDe10 (int[] potencias, int valor) {
        int power10 = 1;
        for (int i = 0; i < potencias.length; i++) {
            if(power10 == valor){
                potencias[i]++;
            } else {

                power10 *= MULTIPLIER;
            }
            System.out.println("Linha para controlo do que eh executado. Encontrei um"
                    + " problema neste metodo que nao faz o que eh suposto fazer!");
        }
    }

}
