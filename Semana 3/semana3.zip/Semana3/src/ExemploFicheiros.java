

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class ExemploFicheiros {


    public static void copiaTexto (String fileIn, String fileOut) throws FileNotFoundException {
        Scanner in = new Scanner (new File(fileIn));
        PrintWriter out = new PrintWriter(fileOut);
        boolean novaLinha = in.hasNext();
        // enquanto o ficheiro nao terminar 
        while (novaLinha){
            out.println(in.nextLine());
            novaLinha = in.hasNext();
        }
        in.close();
        out.close();

    }

    /**
     * regista os quadrados dos numeros de in em out
     * @param in
     * @param out
     * @requires in!=null && out != null e in so com numeros  
     */
    public static void escreveQuadrados(String fileIn, String fileOut)throws FileNotFoundException {
        //removi TO-DO
    }

    public static void guardaMultiplos(String fileIn, String fileOut, int n)throws FileNotFoundException {
        Scanner in = new Scanner(new File(fileIn));
        PrintWriter out = new PrintWriter(new File(fileOut));
        // enquanto o ficheiro nao terminar
        while (in.hasNextInt()){    
            int valorobtido = in.nextInt();
            Calculadora aMinhaCalculadora = new Calculadora();
            aMinhaCalculadora.ehMultiplo(valorobtido,n);
            if (aMinhaCalculadora.ehMultiplo(valorobtido,n)) {
                out.println(valorobtido);
            }
        }
        in.close();
        out.close();
    }

    public static void elementosEmComum(String fileIn, String fileOut, int[] vals)throws FileNotFoundException {
        Scanner leitor = new Scanner (new File(fileIn));
        PrintWriter escritor = new PrintWriter(fileOut);

        boolean fim = false;
        while(!fim){
            int valor = leitor.nextInt();
            for (int i = vals.length; i < vals.length ; i++) {
                if(vals[i] == valor){
                    System.out.println(valor);
                    fim = true;
                    //escritor.write(valor + "\n");
                }
            }
        }
        leitor.close();
        escritor.close();

    }  


    /**
     * Faz a copia das linhas de um ficheiro escrevendo-as noutro ficheiro
     * com as letras todas minusculas e as letras todas maiusculas
     * linha sim linha nao
     * @param fileIn - o nome do ficheiro origem
     * @param fileOut - o nome do ficheiro destino
     * @throws FileNotFoundException
     * @requires fileIn != null && fileOut != null
     */
    public static void minusculasMaiusculas (String fileIn, String fileOut) 

            throws FileNotFoundException{
        Scanner in = new Scanner (new File(fileIn));
        PrintWriter out = new PrintWriter(fileOut);
        boolean flag = true;
        // enquanto o ficheiro nao terminar 
        while (in.hasNextLine()){  
            if(flag) {
                out.write(in.nextLine().toLowerCase() + "\n");
            } else {
                out.write(in.nextLine().toUpperCase() + "\n");
            }
            flag = !flag;          
        }
        in.close();
        out.close();
    }
    /**
     * Calcula o arredondamento dado um algarismo para a dezena mais proxima 
     * @param algarismo - representacao de um algarismo em String
     * @return 0 se 0 <= algarismo < 5 e 10 caso contrario
     * @requires 0 <= algarismo < 10
     */
    public static int metodo(String algarismo) {
        final int a = 10;
        if(algarismo == "5" || algarismo == "6" || algarismo == "7" || algarismo == "8" || algarismo == "9") {
            return a;
        }
        return 0;
    }
}
