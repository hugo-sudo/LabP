public class Recursive {
	/**
	 * 
	 * @param base - valor da base da pot�ncia
	 * @param expoente -  valor do expoente da pot�ncia
	 * @return valor de potencia de base parametro base e de potenica parametro potenica
	 */

	public static double potencia(double base, int expoente) {
		if (expoente == 0) {
			return 1;
		} else if (expoente == 1) {
			return base;
		} else {
			return base * potencia(base ,expoente - 1);
		}
		
	}
	
	/**
	 * 
	 * @param n - n�mero (tipo int) 
	 * @return soma de todos os numero de 1 a n.
	 */
	public static int soma(int n) {
		if (n == 0) {
			return n;
		} else {
			return n + soma (n-1);
		}
	}
	
	/**
	 * 
	 * @param v - lista com numeros (tipo [] int)
	 * @return - maior numero presente na lista de numeros v
	 */
	public static int maior(int[] v) {
		if (v.length == 1) {
			return v[0];
		}
		if (v.length == 2) {
			if (v[0] > v[1]) {
				return v[0];
			} else {
				return v[1];
			}
		} else {
			int [] novaLista = new int [v.length -1];
			if (v[0] >= v[1]) {
				novaLista [0] = v[0];
				for (int i = 1; i < novaLista.length; i ++) {
					novaLista[i] = v[i+1];
				}
				return maior (novaLista);
			} else {
				novaLista [0] = v[1];
				for (int i = 1; i < novaLista.length; i ++) {
					novaLista[i] = v[i+1];
				}
				return maior (novaLista);
			}
		}
	}
		
	/**
	 * 
	 * @param s - palavra (tipo String) 
	 * @param c - carater (tipo Char)
	 * @return - numero de vezes que o carater c esta presente na palavra s.
	 */
	public static int quantosChars(String s, char c) {
		StringBuilder novaPalavra = new StringBuilder (s);
		if (novaPalavra.length() == 1) {
			if (novaPalavra.charAt(0) == c) {
				return 1;
			} else return 0;
		}
		if (novaPalavra.charAt(0) == c) {
			return 1 + quantosChars (novaPalavra.deleteCharAt(0).toString(),c);
		} else {
			return quantosChars (novaPalavra.deleteCharAt(0).toString(),c);
		}
	}
	
	/**
	 * 
	 * @param s - palavra (tipo String)
	 * @param old - carater (tipo char)
	 * @param newer - carater (tipo char)
	 * @return - palavra nova que resulta da substitui�ao do carater old pelo carater newer na palavra s
	 */
	public static String charSubstituido(String s, char old, char newer) {
		StringBuilder novaPalavra = new StringBuilder (s);
		for (int i = 0; i < novaPalavra.length(); i ++) {
			if (novaPalavra.charAt(i) == old) {
				novaPalavra.replace(i, i+1, String.valueOf(newer));
				return charSubstituido (novaPalavra.toString(), old, newer);
			}
		}
		return novaPalavra.toString();
	}
	
	/**
	 * 
	 * @param p - dividendo (tipo int)
	 * @param q -  divisor (tipo int)
	 * @return - maximo divisor comum entre p e q
	 */
	public static int mdc(int p, int q) {
		if (q == 0) {
			return p;
		} else {
			return mdc (q,p%q);
		}
	}

	/**
	 * 
	 * @param l - valor de cima das combinatorias ( tipo int)
	 * @param k - valor de baixo das combinatorias (tipo int)
	 * @return - numero de combina�oes possiveis de l, k a k.
	 */
	public static int combinacoes(int l, int k) {
		if (k > l) {
			return 0;
		}
		if (l == 0 || l == k || k == 0) {
			return 1;
		} else {
			return combinacoes(l-1, k-1) + combinacoes(l-1, k);
			}
	}

	/**
	 * 
	 * @param v - lista de numeros (tipo int)
	 * @param n - numero (tipo int)
	 * @return - true se n pertencer a v, false caso contrario
	 */
	public static boolean pertence(int[] v, int n) {
		if ((v.length == 1) && (v[0] == n)) {
			return true;
		} 
		if (v.length > 1) {
			int [] novaLista = new int [v.length -1];
			if (v[0] == n) {
				return true;
			} else {
				for (int i = 0; i<novaLista.length; i++) {
					novaLista [i] = v[i+1];
				}
				return pertence (novaLista, n);
			}
		}
		return false;
	}

	/**
	 * 
	 * @param v - lista de numeros (tipo [] int)
	 * @return - retorna true se v � sim�trico, ou seja, se o
		primeiro e o �ltimo elementos s�o iguais e se o segundo e o pen�ltimo elementos s�o
		iguais, etc, assumindo que v � um vetor n�o vazio;
	 */
	public static boolean ehSimetrico(int[] v) {
		if (v.length == 1) {
			return true;
		}
		if ((v.length == 2) && (v[0] == v[1])) {
			return true;
		}
		if (v [0] == v [v.length -1]) {
			int [] novaLista = new int [v.length -2];
			for (int i = 0; i < novaLista.length; i++) {
				novaLista[i] = v[i+1];
			}
			return ehSimetrico(novaLista);
		}
		return false;
	}

	/**
	 * 
	 * @param v -lista de numeros (tipo int [])
	 * @return - devolve true se a lista de numeros estiver ordenada por ordem crescente, false caso contrario
	 */
	public static boolean ordenado(double[] v) {
		if (v.length == 1) {
			return true;
		}
		if (v[0] <= v[1]) {
			double [] novo = new double[v.length-1];
			for (int i = 1; i < v.length; i ++) {
				novo[i-1] =v[i]; 
			}
			return ordenado (novo);
		} else {
			return false;
		}
	}

	/**
	 * 
	 * @param n - numero (tipo int)
	 * @return - valor de n em bin�rio
	 */
	public static String intToBin(int n) {
		if (n == 1) {
			return "1";
		} else if (n == 0) {
			return "0";
		}
		if (n % 2 == 0) {
			return intToBin (n / 2) + "0";
		} else {
			return intToBin (n / 2) + "1";
		}
	}

	/**
	 * 
	 * @param l - numero de lados de um triangulo isosceles (tipo int)
	 * @return - calcula e devolve o n�mero total de blocos que um tri�ngulo is�sceles com n linhas tem, assumindo que n � maior que zero;
	 */
	public static int quantosBlocos(int l) {
		if (l == 1) {
			return l;
		}
		return l + quantosBlocos (l - 1);
	}

	/**
	 * 
	 * @param l - numero de coelhos (tipo int)
	 * @return - Imagine um conjunto de coelhos alinhados em fila
		indiana, numerados 1, 2, � Os coelhos �mpares, por terem uma pata levantada
		aparentam ter 3 orelhas. Este m�todo deve calcular e devolver o n�mero de orelhas
		aparentes que se v�em numa fila com n coelhos, assumindo que n � positivo;
	 */
	public static int numeroOrelhas(int l) {
		if (l == 1) {
			return 3;
		}
		if (l % 2 == 0) {
			return 2 + numeroOrelhas (l - 1);
		} else {
			return 3 + numeroOrelhas (l - 1);
		}
	}

	/**
	 * 
	 * @param l - numero (tipo int)
	 * @return - Soma de todos os algarismos de l
	 */
	public static int somaAlgarismos(int l) {
		if (l < 10) {
			return l;
		} else {
			return (l % 10) + somaAlgarismos (l / 10);
		}
	}

	/**
	 * 
	 * @param n - numero (tipo int)
	 * @return - retorna true se n for um numero primo, falso caso contario. (chama a fun��o ehPrimoAux)
	 */
	public static boolean ehPrimo(int n) {
		return ehPrimoAux (n,3);
	}
	
	/**
	 * 
	 * @param n - numero (tipo int)
	 * @param v - valor do divisor que esta a ser usado
	 * @return - fun�ao auxiliar � fun��o ehPrimo, permite verificar se um numero � primo dividindo valor n pelo v que est� em contante atualiza�ao
	 * a cada chamada da fun��o.
	 */
	public static boolean ehPrimoAux(int n, int v) {
	    if (n < 2) {
	        return false;
	    }

	    if (n % 2 == 0) {
	        return (n == 2);
	    }

	    if (v * v > n) {
	        return true;
	    }

	    if (n % v == 0) {
	        return false;
	    }

	    return ehPrimoAux(n, v + 2);
	}
	
	
	/**
	 * 
	 * @param n - numero (tipo int)
	 * @param m - numero (tipo int)
	 * @return - resultado da multiplica��o de n por m.
	 */
	public static int produto(int n, int m) {
		if ((m == 0) || (n == 0)) {
			return 0;
		}
		if (m > 0) {
			if (m == 1) {
				return n;
			} 
			return n + produto (n, m -1);
		}
		else if (n > 0){
			if (n == 1) {
				return m;
			} 
			return m + produto (n - 1, m);
		} else {
			return n*-1 + produto (n, m +1);
		}
	}

	/**
	 * 
	 * @param n - numero (tipo int)
	 * @return - valor da soma dos quadrados de todos os numeros entre 0 e n
	 */
	public static int somaQuadrados(int n) {
		if (n == 1) {
			return 1;
		}
		return n*n + somaQuadrados (n - 1);
	}

	/**
	 * 
	 * @param l - numero (tipo int)
	 * @return - numero de algarismos que l cont�m
	 */
	public static int quantosAlgarismos(int l) {
		if (l < 10) {
			return 1;
		} else {
			return 1 + quantosAlgarismos (l /10);
		}
	}


}
