import static org.junit.Assert.*;

import org.junit.Test;

public class TesteEx07 {
	
	private int esperado;
	private int obtido;
	
	private int l;
	private int k;
	
	@Test
	public void lEhZero () {
		l = 0;
		k = 10;
		
		esperado = 	0;		
		obtido = Recursive.combinacoes(l, k);
		
		assertEquals(esperado,obtido);

	}
	
	@Test
	public void lEhUm () {
		l = 1;
		k = 1;
		
		esperado = 	1;		
		obtido = Recursive.combinacoes(l, k);
		
		assertEquals(esperado,obtido);

	}
	
	
	@Test
	public void kMaiorQueL () {
		l = 15;
		k = 20;
		
		esperado = 	0;		
		obtido = Recursive.combinacoes(l, k);
		
		assertEquals(esperado,obtido);

	}
	
	@Test
	public void lIgualAKMaiorQue1 () {
		l = 12;
		k = 12;
		
		esperado = 	1;		
		obtido = Recursive.combinacoes(l, k);
		
		assertEquals(esperado,obtido);

	}
	
	@Test
	public void kEh1 () {
	    l = 12;
	    k = 1;

	    esperado =  12;      
	    obtido = Recursive.combinacoes(l, k);

	    assertEquals(esperado,obtido);

	}

	@Test
	public void kEh0LGrande () {
	    l = 12;
	    k = 0;

	    esperado =  1;      
	    obtido = Recursive.combinacoes(l, k);

	    assertEquals(esperado,obtido);

	}

	@Test
	public void lMaiorQueK () {
	    l = 12;
	    k = 6;

	    esperado =  924;      
	    obtido = Recursive.combinacoes(l, k);
	    
	    assertTrue(esperado == obtido);

	}

	@Test
	public void doEnunciado () {
	    l = 6;
	    k = 4;

	    esperado =  15;      
	    obtido = Recursive.combinacoes(l, k);
	    
	    assertTrue(esperado == obtido);

	}

}
