
public class ParDeSimbolos {
	private String simboloAbertura;
	private String simboloFecho;
	
	public ParDeSimbolos (String abertura,String fecho) {
		simboloAbertura = abertura;
		simboloFecho = fecho;
	}

	public String getAbertura() {
		return simboloAbertura;
	}
	
	public String getFecho() {
		return simboloFecho;
	}
}
