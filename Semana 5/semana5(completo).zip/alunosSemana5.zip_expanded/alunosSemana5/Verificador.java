import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class Verificador {

	public static void main(String[] args) throws FileNotFoundException {

		Scanner ficheiroSimbolos = new Scanner (new File(args[0]));
		Scanner ficheiroExpressoes = new Scanner (new File(args[1]));
		
		PrintWriter resultado = new PrintWriter (args[2]);
		
		Stack<String> pilha = new Stack<>();
		
		ArrayList<ParDeSimbolos> simbolos = new ArrayList<ParDeSimbolos>();
		
		boolean avalia = true;
		while (ficheiroSimbolos.hasNextLine()) {
			String linhaSimbolos = ficheiroSimbolos.nextLine();
			String [] elemento = linhaSimbolos.split(" ");
			simbolos.add(new ParDeSimbolos (elemento [0], elemento [1]));
		}
		while (ficheiroExpressoes.hasNextLine()) {
			String linha = ficheiroExpressoes.nextLine();
			String [] valores = linha.split(" ");
			for (String expre :valores) {
				avalia = true;
				for (ParDeSimbolos simbolo: simbolos) {
					if (avalia) {
						if (expre.equals(simbolo.getAbertura())) {
							pilha.addElement(expre); 
						} else if (expre.equals(simbolo.getFecho()) && simbolo.getAbertura().equals(pilha.peek())) {
							pilha.pop();
						} else if (expre.equals(simbolo.getFecho()) && !(simbolo.getAbertura().equals(pilha.peek()))) {
							int contador = 0;
							for (String valorPilha : pilha) {
								if (valorPilha.equals(simbolo.getAbertura())) {
									contador += 1;
								}
							}
							if (contador == 0) {
								resultado.println(linha + " ==> encontrei " + simbolo.getFecho() + " extempor�neo" );
								avalia = false;
								pilha.clear();
							} else {
								for (ParDeSimbolos simboloFinal : simbolos) {
									if (pilha.peek().equals(simboloFinal.getAbertura())) {
										resultado.println(linha + " ==> esperava " + simboloFinal.getFecho() + " encontrei " + simbolo.getFecho());
										avalia = false;
									}
								}
							}
							
						}
					}
				}
			}
			
			if (pilha.empty() && avalia) {
				resultado.println(linha + " ==> ok");
			}

		} 
		
		ficheiroSimbolos.close();
		ficheiroExpressoes.close();
		resultado.close();

	}

}
