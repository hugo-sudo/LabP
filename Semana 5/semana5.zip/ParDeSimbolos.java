/**
 * 
 * @author fc51589
 *
 */
public class ParDeSimbolos {
	private String simboloAbertura;
	private String simboloFecho;
	
	/**
	 * Objeto com o simbolo de fecho e com o s�mbolo de abertura
	 * @param abertura - S�mbolo de abertura da express�o
	 * @param fecho -  s�mbolo de fecho da express�o
	 */
	public ParDeSimbolos (String abertura,String fecho) {
		simboloAbertura = abertura;
		simboloFecho = fecho;
	}

	public String getAbertura() {
		return simboloAbertura;
	}
	
	public String getFecho() {
		return simboloFecho;
	}
}
