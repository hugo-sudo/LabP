import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;
/**
 * 
 * @author fc51589
 *
 */
public class Verificador {
	
	/**
	 * Verifica se as expressoes indicadas no ficheiro de texto s�o validas ou n�o, tem 3 argumentos.
	 * @param args - 1� ficheiro com express�es a serem verificadas, cada linha � uma expres�o
	 * 				 2� ficheiro com s�mbolos que ir�o servir para ver se as express�es est�o a usar a sintaxe correta
	 * 				 3� ficheiro de sa�da, que vai indicar se cada express�o est� ou n�o correta
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {

		Scanner ficheiroSimbolos = new Scanner (new File(args[0]));
		Scanner ficheiroExpressoes = new Scanner (new File(args[1]));
		
		PrintWriter resultado = new PrintWriter (args[2]);
		
		int contador = 0;
		Stack<String> pilha = new Stack<>();
		
		ArrayList<ParDeSimbolos> simbolos = new ArrayList<ParDeSimbolos>();
		
		
		boolean avalia = true;
		while (ficheiroSimbolos.hasNextLine()) {
			String linhaSimbolos = ficheiroSimbolos.nextLine();
			String [] elemento = linhaSimbolos.split(" ");
			simbolos.add(new ParDeSimbolos (elemento [0], elemento [1]));
		}
		while (ficheiroExpressoes.hasNextLine()) {
			String linha = ficheiroExpressoes.nextLine();
			String [] valores = linha.split(" ");
			for (String expre :valores) {
				avalia = true;
				for (ParDeSimbolos simbolo: simbolos) {
					if (avalia) {
						if (expre.equals(simbolo.getAbertura())) {
							pilha.addElement(expre); 
						} else if (!(pilha.empty()) && expre.equals(simbolo.getFecho()) && simbolo.getAbertura().equals(pilha.peek())) {
							pilha.pop();
						} else if ((pilha.empty()) && expre.equals(simbolo.getFecho()) && contador == 0) {
							resultado.println(linha + " ==> encontrei " + simbolo.getFecho() + " extempor�neo");
							avalia = false;
							contador += 1;
						} else if (!(pilha.empty()) && expre.equals(simbolo.getFecho()) && !(simbolo.getAbertura().equals(pilha.peek()))) {
							for (ParDeSimbolos simboloFinal : simbolos) {
								if (pilha.peek().equals(simboloFinal.getAbertura())) {
									resultado.println(linha + " ==> esperava " + simboloFinal.getFecho() + " encontrei " + simbolo.getFecho());
									avalia = false;
								}
							}
						}
					}
				}
			}
			if (pilha.empty() && avalia && contador == 0) {
				resultado.println(linha + " ==> ok");
			} else{
				pilha.clear();
			}
		}
			
			
			
		
		ficheiroSimbolos.close();
		ficheiroExpressoes.close();
		resultado.close();
		
	}

}
