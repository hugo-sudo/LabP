import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Classe cujas instancias sabem criar pacotes a partir de uma lista de entradas
 * 
 * @author Fc51589 - Hugo Vieira
 */
public class GestorPacotes<K, F> {
	// Colecao dos pacotes
	private List<Pacote<Par<K, F>>> pacotes;
	// Capacidade maxima de cada pacote
	private int capacidadePacotes;

	/**
	 * Construtor
	 * 
	 * @param capacidadePacotes Capacidade maxima de cada pacote
	 * @requires capacidadePacotes > 0
	 */
	public GestorPacotes(int capacidadePacotes) {
		this.pacotes = new ArrayList<>();
		this.capacidadePacotes = capacidadePacotes;
	}

	/**
	 * Cria pacotes de entradas a partir de uma lista de entradas Cada entrada eh um
	 * par Cada pacote contem apenas entradas com valores iguais dos seus primeiros
	 * elementos
	 * 
	 * @param entradas A lista com as entradas a empacotar
	 */
	public void criaPacotes(List<Par<K, F>> entradas) {
		for (Par <K, F> entrada : entradas) {
			int a  = 0;
			//System.out.println(entrada);
			//System.out.println(pacotes);
			//System.out.println(entrada.primeiro());
			//System.out.println(pacotes.iterator().next().iterator().next().primeiro());
			//if (pacotes.iterator().hasNext()) {
			int i = pacotes.size();
			System.out.println("Size: " + i);
			Iterator<Pacote<Par<K, F>>> pac = pacotes.iterator();
			while (pac.hasNext()) {
				Pacote<Par<K, F>> pacoteAtual = pac.next();
				Iterator<Par<K, F>> par = pacoteAtual.iterator();
				Par <K, F> parAtual = par.next();
				//System.out.println("Pac: " + pacoteAtual);
				//System.out.println("Par: " + parAtual);
				//System.out.println("entrada: " + entrada);
				//System.out.println(entrada.primeiro());
				//System.out.println(pacotes.iterator().next().iterator().next().primeiro());
				if (verificaK(parAtual.primeiro(),entrada.primeiro()) && !pacoteAtual.estaCheio()) {
					pacoteAtual.empacota(entrada);
					a = 1;
				}
				
			}
			if (a == 0) {
				Pacote<Par<K, F>> encomenda = new Pacote<Par<K, F>>(capacidadePacotes);
				encomenda.empacota(entrada);
				System.out.println("Encomenda: " + encomenda);
				pacotes.add(encomenda);
			}
		}
	}
	/*
	 * Verifica se os dois valores de K sao iguais
	 */
	public boolean verificaK (K atual, K recebido) {
		return (atual.equals(recebido));
	}
	/*
	 * Verifica se os dois valores de F sao iguais
	 */
	public boolean verificaF (F atual, F recebido) {
		return (atual.equals(recebido));
	}
	/**
	 * O numero total de elementos guardados nos pacotes deste gestor de pacotes
	 */
	public int numeroElementosEmpacotados() {
		int contador = 0;
		Iterator<Pacote<Par<K, F>>> pac = pacotes.iterator();
		while(pac.hasNext()) {
			Pacote<Par<K, F>> pacoteAtual = pac.next();
			if(pacoteAtual.estaCheio()) {
				contador +=2;
			} else {
				contador ++;
			}
		}
		return contador;
	}

	/**
	 * Numero de pacotes deste gestor de pacotes
	 */
	public int numeroPacotes() {
		return pacotes.size();
	}

	/**
	 * Numero de pacotes deste gestor de pacotes que teem um dado primeiro elemento
	 * 
	 * @paramp prim Primeiro elemento a pesquisar
	 * @return Numero de pacotes com primeiro elemento igual a prim
	 * 
	 */
	public int numeroElementosK(K prim) {
		int contador = 0;
		int i = pacotes.size();
		Iterator<Pacote<Par<K, F>>> pac = pacotes.iterator();
		while (pac.hasNext()) {
			Pacote<Par<K, F>> pacoteAtual = pac.next();
			Iterator<Par<K, F>> par = pacoteAtual.iterator();
			Par <K, F> parAtual = par.next();
			if (verificaK (parAtual.primeiro(),prim)) {
				contador ++;
			}
		}
		return contador;
	}

	/**
	 * Lista com os primeiros elementos dos pares cujo segundo elemento tem o valor
	 * dado
	 * 
	 * @param seg Valor do segundo elemento do par a procurar
	 * @return A lista de primeiros elementos dos pares que teem seg como segundo
	 *         elemento
	 */
	public List<K> listaElementosK(F seg) {
		List<K> myList = new ArrayList<>();
		Iterator<Pacote<Par<K, F>>> pac = pacotes.iterator();
		while(pac.hasNext()) {
			Pacote<Par<K, F>> pacoteAtual = pac.next();
			Iterator<Par<K, F>> par = pacoteAtual.iterator();
			Par <K, F> parAtual = par.next();
			if (verificaF (parAtual.segundo(),seg)) {
				myList.add(parAtual.primeiro());
			}
		}
		return myList;
	}

	/**
	 * Representacao textual dos pacotes criados, um por linha
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (Pacote<Par<K, F>> pEmp : pacotes) {
			sb.append(pEmp.toString() + "\n");
		}
		return sb.toString();
	}

}
